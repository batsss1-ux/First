-- Migration for "校园营养餐配送管理系统"
-- Enable pgcrypto if not enabled
CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- USERS TABLE
CREATE TABLE IF NOT EXISTS public.users (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  name text NOT NULL,
  role text NOT NULL CHECK (role IN ('student', 'parent', 'admin', 'delivery')),
  phone text,
  class_name text,
  parent_id uuid REFERENCES public.users(id),
  area text,
  created_at timestamptz DEFAULT now()
);
ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.get_auth_user_role()
RETURNS text
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
STABLE
AS $$
  SELECT role FROM public.users WHERE id = auth.uid();
$$;

CREATE POLICY "Enable read access for all authenticated users" ON public.users FOR SELECT TO authenticated USING (true);
CREATE POLICY "Users can insert their own profile" ON public.users FOR INSERT TO authenticated WITH CHECK (auth.uid() = id);
CREATE POLICY "Users can update own profile" ON public.users FOR UPDATE TO authenticated USING (auth.uid() = id);
CREATE POLICY "Admins can update all users" ON public.users FOR UPDATE TO authenticated USING (public.get_auth_user_role() = 'admin');
CREATE POLICY "Admins can delete users" ON public.users FOR DELETE TO authenticated USING (public.get_auth_user_role() = 'admin');

-- DISHES TABLE
CREATE TABLE IF NOT EXISTS public.dishes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  image_url text,
  calories integer NOT NULL,
  protein numeric NOT NULL,
  fat numeric NOT NULL,
  carbs numeric NOT NULL,
  created_at timestamptz DEFAULT now()
);
ALTER TABLE public.dishes ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Dishes are viewable by everyone" ON public.dishes FOR SELECT TO authenticated USING (true);
CREATE POLICY "Admins can insert dishes" ON public.dishes FOR INSERT TO authenticated WITH CHECK (public.get_auth_user_role() = 'admin');
CREATE POLICY "Admins can update dishes" ON public.dishes FOR UPDATE TO authenticated USING (public.get_auth_user_role() = 'admin');
CREATE POLICY "Admins can delete dishes" ON public.dishes FOR DELETE TO authenticated USING (public.get_auth_user_role() = 'admin');

-- MENUS TABLE
CREATE TABLE IF NOT EXISTS public.menus (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  date date NOT NULL,
  name text NOT NULL,
  type text NOT NULL CHECK (type IN ('daily', 'weekly')),
  created_at timestamptz DEFAULT now()
);
ALTER TABLE public.menus ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Menus are viewable by everyone" ON public.menus FOR SELECT TO authenticated USING (true);
CREATE POLICY "Admins can manage menus" ON public.menus FOR ALL TO authenticated USING (public.get_auth_user_role() = 'admin');

-- MENU DISHES TABLE
CREATE TABLE IF NOT EXISTS public.menu_dishes (
  menu_id uuid REFERENCES public.menus(id) ON DELETE CASCADE,
  dish_id uuid REFERENCES public.dishes(id) ON DELETE CASCADE,
  PRIMARY KEY (menu_id, dish_id)
);
ALTER TABLE public.menu_dishes ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Menu dishes are viewable by everyone" ON public.menu_dishes FOR SELECT TO authenticated USING (true);
CREATE POLICY "Admins can manage menu dishes" ON public.menu_dishes FOR ALL TO authenticated USING (public.get_auth_user_role() = 'admin');

-- ORDERS TABLE
CREATE TABLE IF NOT EXISTS public.orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_number text UNIQUE,
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES public.users(id) ON DELETE CASCADE,
  student_id uuid REFERENCES public.users(id),
  menu_id uuid REFERENCES public.menus(id),
  target_date date NOT NULL,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'paid', 'refunded', 'cancelled')),
  delivery_status text NOT NULL DEFAULT 'pending' CHECK (delivery_status IN ('pending', 'delivering', 'delivered')),
  delivery_person_id uuid REFERENCES public.users(id),
  total_calories integer,
  total_protein numeric,
  total_fat numeric,
  total_carbs numeric,
  created_at timestamptz DEFAULT now()
);
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users can view their own orders" ON public.orders FOR SELECT TO authenticated USING (
  auth.uid() = user_id OR auth.uid() = student_id OR auth.uid() = delivery_person_id OR public.get_auth_user_role() = 'admin'
);
CREATE POLICY "Users can insert their own orders" ON public.orders FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update their own orders" ON public.orders FOR UPDATE TO authenticated USING (
  auth.uid() = user_id OR auth.uid() = delivery_person_id OR public.get_auth_user_role() = 'admin'
);

-- ORDER DISHES TABLE
CREATE TABLE IF NOT EXISTS public.order_dishes (
  order_id uuid REFERENCES public.orders(id) ON DELETE CASCADE,
  dish_id uuid REFERENCES public.dishes(id) ON DELETE CASCADE,
  quantity integer NOT NULL DEFAULT 1,
  PRIMARY KEY (order_id, dish_id)
);
ALTER TABLE public.order_dishes ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users can view their own order dishes" ON public.order_dishes FOR SELECT TO authenticated USING (
  EXISTS (SELECT 1 FROM public.orders o WHERE o.id = order_id AND (
    o.user_id = auth.uid() OR o.student_id = auth.uid() OR o.delivery_person_id = auth.uid() OR public.get_auth_user_role() = 'admin'
  ))
);
CREATE POLICY "Users can insert order dishes" ON public.order_dishes FOR INSERT TO authenticated WITH CHECK (
  EXISTS (SELECT 1 FROM public.orders o WHERE o.id = order_id AND o.user_id = auth.uid())
);
CREATE POLICY "Admins can update/delete order dishes" ON public.order_dishes FOR ALL TO authenticated USING (
  public.get_auth_user_role() = 'admin'
);

-- ANNOUNCEMENTS TABLE
CREATE TABLE IF NOT EXISTS public.announcements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  content text NOT NULL,
  author_id uuid REFERENCES public.users(id),
  created_at timestamptz DEFAULT now()
);
ALTER TABLE public.announcements ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Announcements are viewable by everyone" ON public.announcements FOR SELECT TO authenticated USING (true);
CREATE POLICY "Admins can manage announcements" ON public.announcements FOR ALL TO authenticated USING (
  public.get_auth_user_role() = 'admin'
);

-- Order number auto generation trigger
CREATE SEQUENCE IF NOT EXISTS order_number_seq;
CREATE OR REPLACE FUNCTION generate_order_number()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.order_number IS NULL THEN
    NEW.order_number := 'ORD' || to_char(now(), 'YYYYMMDD') || lpad(nextval('order_number_seq')::text, 6, '0');
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_generate_order_number
BEFORE INSERT ON public.orders
FOR EACH ROW
EXECUTE FUNCTION generate_order_number();

-- SEED DATA
INSERT INTO public.dishes (name, image_url, calories, protein, fat, carbs) VALUES 
('红烧肉', 'https://miaoda-site-img.cdn.bcebos.com/images/baidu_image_search_f05c45a5-6cff-4e50-9161-f9725eb0963a.jpg', 550, 15.5, 45.2, 10.5),
('番茄炒蛋', 'https://miaoda-site-img.cdn.bcebos.com/images/baidu_image_search_cf9d728d-e5bf-4545-b581-d7d59ce31efd.jpg', 220, 12.0, 15.0, 8.0),
('清炒时蔬', 'https://miaoda-site-img.cdn.bcebos.com/images/baidu_image_search_65479218-6307-47ef-bb63-2a9e3468cec2.jpg', 80, 2.5, 3.0, 10.0),
('紫菜蛋花汤', 'https://miaoda-site-img.cdn.bcebos.com/images/baidu_image_search_ce62df81-dcbf-4f0d-8a6b-4b8fbacecbf1.jpg', 60, 4.0, 3.5, 2.0),
('炸鸡腿', 'https://miaoda-site-img.cdn.bcebos.com/images/baidu_image_search_b703a1dd-bdba-42f6-98fd-44e0ce344a19.jpg', 350, 25.0, 20.0, 15.0);
