ALTER TABLE public.dishes ADD COLUMN IF NOT EXISTS price numeric NOT NULL DEFAULT 10.0;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS total_price numeric;

-- 给已有的菜品设置一个随机的默认金额（10 ~ 30之间）
UPDATE public.dishes SET price = FLOOR(RANDOM() * 20 + 10) WHERE price = 10.0;
