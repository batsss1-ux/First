ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS rating integer;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS review text;
