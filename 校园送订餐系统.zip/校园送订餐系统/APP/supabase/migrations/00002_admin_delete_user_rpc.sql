CREATE OR REPLACE FUNCTION public.delete_user_by_admin(target_user_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth
AS $$
BEGIN
  -- 只有管理员可以执行此操作
  IF public.get_auth_user_role() != 'admin' THEN
    RAISE EXCEPTION 'Access denied. Admin role required.';
  END IF;

  -- 从 auth.users 表中删除用户，由于设置了 ON DELETE CASCADE，
  -- public.users 和相关的依赖表中的对应数据也会被一并删除
  DELETE FROM auth.users WHERE id = target_user_id;
END;
$$;