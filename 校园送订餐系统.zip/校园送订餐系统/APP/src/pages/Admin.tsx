import { useState, useEffect } from "react";
import { MainLayout } from "@/components/layouts/MainLayout";
import { supabase } from "@/db/supabase";

export default function Admin() {
  const [stats, setStats] = useState({ 
    todayOrders: 0, 
    pendingDeliveries: 0, 
    totalUsers: 0,
    totalRevenue: 0,
    completedOrders: 0,
    deliveringOrders: 0
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchStats() {
      const today = new Date().toISOString().split('T')[0];
      
      const { count: ordersCount } = await supabase.from('orders').select('*', { count: 'exact', head: true }).gte('target_date', today);
      
      const { data: revenueData } = await supabase.from('orders').select('total_price').in('status', ['paid', 'completed']);
      const totalRevenue = revenueData?.reduce((acc, curr) => acc + Number(curr.total_price || 0), 0) || 0;
      
      const { count: completedCount } = await supabase.from('orders').select('*', { count: 'exact', head: true }).eq('delivery_status', 'delivered');
      
      const { count: deliveringCount } = await supabase.from('orders').select('*', { count: 'exact', head: true }).eq('delivery_status', 'delivering');
      
      const { count: pendingCount } = await supabase.from('orders').select('*', { count: 'exact', head: true }).eq('delivery_status', 'pending').eq('status', 'paid');
      
      const { count: usersCount } = await supabase.from('users').select('*', { count: 'exact', head: true });

      setStats({
        todayOrders: ordersCount || 0,
        pendingDeliveries: pendingCount || 0,
        totalUsers: usersCount || 0,
        totalRevenue: totalRevenue,
        completedOrders: completedCount || 0,
        deliveringOrders: deliveringCount || 0
      });
      setLoading(false);
    }
    fetchStats();
  }, []);

  return (
    <MainLayout role="admin">
      <div className="space-y-6">
        <h1 className="text-3xl font-bold border-b-4 border-foreground pb-2">管理员控制台</h1>
        {loading ? (
          <div className="text-center font-bold text-xl py-10">LOADING...</div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <div className="bg-card p-6 border-4 border-foreground retro-shadow col-span-1 md:col-span-2 lg:col-span-3 bg-primary/10 border-primary">
              <h2 className="text-xl font-bold mb-2 text-primary">总销售额 (已支付订单)</h2>
              <p className="text-5xl font-bold text-primary">¥{stats.totalRevenue.toFixed(2)}</p>
            </div>
            
            <div className="bg-card p-6 border-4 border-foreground retro-shadow">
              <h2 className="text-xl font-bold mb-2 text-foreground">今日及未来订单</h2>
              <p className="text-4xl font-bold">{stats.todayOrders}</p>
            </div>
            
            <div className="bg-card p-6 border-4 border-foreground retro-shadow">
              <h2 className="text-xl font-bold mb-2 text-secondary">待处理配送</h2>
              <p className="text-4xl font-bold">{stats.pendingDeliveries}</p>
            </div>
            
            <div className="bg-card p-6 border-4 border-foreground retro-shadow">
              <h2 className="text-xl font-bold mb-2 text-accent text-accent-foreground">配送中订单</h2>
              <p className="text-4xl font-bold">{stats.deliveringOrders}</p>
            </div>
            
            <div className="bg-card p-6 border-4 border-foreground retro-shadow">
              <h2 className="text-xl font-bold mb-2 text-primary">已完成订单</h2>
              <p className="text-4xl font-bold">{stats.completedOrders}</p>
            </div>
            
            <div className="bg-card p-6 border-4 border-foreground retro-shadow">
              <h2 className="text-xl font-bold mb-2 text-foreground">注册用户数</h2>
              <p className="text-4xl font-bold">{stats.totalUsers}</p>
            </div>
          </div>
        )}
      </div>
    </MainLayout>
  );
}