import { useState, useEffect } from "react";
import { MainLayout } from "@/components/layouts/MainLayout";
import { supabase } from "@/db/supabase";
import { useAuth } from "@/contexts/AuthContext";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Bell } from "lucide-react";

export default function Student() {
  const { user } = useAuth();
  const [todayOrder, setTodayOrder] = useState<any>(null);
  const [announcements, setAnnouncements] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchData() {
      if (!user) return;
      const today = new Date().toISOString().split('T')[0];
      
      const [orderRes, annRes] = await Promise.all([
        supabase.from('orders')
          .select('*, menus(name)')
          .eq('user_id', user.id)
          .eq('target_date', today)
          .limit(1)
          .maybeSingle(),
        supabase.from('announcements')
          .select('*')
          .order('created_at', { ascending: false })
          .limit(3)
      ]);
      
      if (orderRes.data) setTodayOrder(orderRes.data);
      if (annRes.data) setAnnouncements(annRes.data);
      
      setLoading(false);
    }
    fetchData();
  }, [user]);

  return (
    <MainLayout role="student">
      <div className="space-y-6">
        <h1 className="text-3xl font-bold border-b-4 border-foreground pb-2">学生中心</h1>
        
        {announcements.length > 0 && (
          <div className="bg-accent/20 p-4 border-4 border-accent retro-shadow mb-6">
            <h2 className="text-lg font-bold mb-2 flex items-center text-accent-foreground">
              <Bell className="w-5 h-5 mr-2" /> 最新公告
            </h2>
            <div className="space-y-2">
              {announcements.map((ann, idx) => (
                <div key={idx} className="border-b-2 border-accent/30 pb-2 last:border-0 last:pb-0">
                  <h3 className="font-bold">{ann.title}</h3>
                  <p className="text-sm mt-1">{ann.content}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-card p-6 border-4 border-foreground retro-shadow flex flex-col">
            <h2 className="text-xl font-bold mb-4">欢迎回来！</h2>
            <p className="text-muted-foreground mb-6 flex-1">在这里您可以查看每日菜单、订餐并查看营养摄入报表。</p>
            <Link to="/student/order">
              <Button className="w-full font-bold retro-btn border-2 border-foreground">
                去查看今日菜单
              </Button>
            </Link>
          </div>

          <div className="bg-card p-6 border-4 border-foreground retro-shadow flex flex-col">
            <h2 className="text-xl font-bold mb-4">今日订单状态</h2>
            {loading ? (
              <div className="font-bold">LOADING...</div>
            ) : todayOrder ? (
              <div className="flex flex-col flex-1">
                <p className="font-bold mb-2">套餐：{todayOrder.menus?.name || '自定义套餐'}</p>
                <p className="font-bold mb-2 text-primary">状态：{
                  todayOrder.status === 'paid' ? '已支付' : 
                  todayOrder.status === 'pending' ? '待支付' : 
                  todayOrder.status === 'cancelled' ? '已取消' : '已退款'
                }</p>
                <p className="font-bold mb-4 text-secondary">配送：{
                  todayOrder.delivery_status === 'pending' ? '待处理' : 
                  todayOrder.delivery_status === 'delivering' ? '配送中' : '已送达'
                }</p>
                <div className="mt-auto">
                  <Link to="/student/history">
                    <Button variant="outline" className="w-full font-bold retro-btn border-2 border-foreground">
                      查看详情
                    </Button>
                  </Link>
                </div>
              </div>
            ) : (
              <div className="text-center py-4 flex flex-col flex-1">
                <p className="font-bold text-muted-foreground mb-4">您今天还没有订餐哦</p>
                <div className="mt-auto">
                  <Link to="/student/order">
                    <Button className="w-full font-bold retro-btn border-2 border-foreground bg-primary text-primary-foreground hover:bg-primary/90 hover:text-primary-foreground">
                      立即订餐
                    </Button>
                  </Link>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </MainLayout>
  );
}