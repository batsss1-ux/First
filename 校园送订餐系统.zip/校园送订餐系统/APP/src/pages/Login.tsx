import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/db/supabase";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import { Utensils } from "lucide-react";

declare global {
  interface Window {
    isSigningUp?: boolean;
  }
}

export default function Login() {
  const { user, userRole, loading: authLoading } = useAuth();
  const [isLogin, setIsLogin] = useState(true);
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [role, setRole] = useState("student");
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    if (user && !authLoading && isLogin && !window.isSigningUp) {
      navigate(`/${userRole || 'student'}`);
    }
  }, [user, userRole, authLoading, isLogin, navigate]);

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    const authEmail = username.includes('@') ? username : `${username}@system.local`;

    try {
      if (isLogin) {
        const { data, error } = await supabase.auth.signInWithPassword({ email: authEmail, password });
        if (error) throw error;
        
        // Fetch role to redirect
        const { data: userData, error: userError } = await supabase.from("users").select("role").eq("id", data.user.id).single();
        if (userError) throw userError;
        
        toast.success("登录成功！");
        navigate(`/${userData.role}`);
      } else {
        const { data, error } = await supabase.auth.signUp({ email: authEmail, password });
        if (error) throw error;
        
        if (data.user) {
          window.isSigningUp = true;
          const { error: insertError } = await supabase.from("users").insert({
            id: data.user.id,
            name: name,
            role: role,
            phone: phone
          });
          if (insertError) {
            window.isSigningUp = false;
            throw insertError;
          }
          
          // 如果注册后自动登录了，强制退出以返回登录界面
          await supabase.auth.signOut();
          window.isSigningUp = false;
          
          toast.success("注册成功！请使用新账号登录。");
          setIsLogin(true);
          setPassword("");
        }
      }
    } catch (error: any) {
      toast.error(error.message || "操作失败");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-background retro-font p-4">
      <div className="w-full max-w-md bg-card p-8 border-4 border-foreground retro-shadow">
        <div className="flex flex-col items-center mb-8">
          <div className="p-4 bg-primary rounded-none border-4 border-foreground retro-shadow mb-4">
            <Utensils className="w-12 h-12 text-primary-foreground" />
          </div>
          <h1 className="text-3xl font-bold text-center">校园送订餐系统</h1>
          <p className="text-muted-foreground mt-2 font-bold">{isLogin ? "欢迎回来！" : "注册新账号"}</p>
        </div>

        <form onSubmit={handleAuth} className="space-y-4">
          {!isLogin && (
            <>
              <div className="space-y-2">
                <label className="font-bold">用户姓名</label>
                <Input 
                  value={name} 
                  onChange={e => setName(e.target.value)} 
                  required 
                  placeholder="请输入姓名"
                  className="border-2 border-foreground rounded-none p-2 h-12 text-lg"
                />
              </div>
              <div className="space-y-2">
                <label className="font-bold">联系电话</label>
                <Input 
                  value={phone} 
                  onChange={e => setPhone(e.target.value)} 
                  required 
                  placeholder="请输入手机号码"
                  className="border-2 border-foreground rounded-none p-2 h-12 text-lg"
                />
              </div>
              <div className="space-y-2">
                <label className="font-bold">选择身份</label>
                <Select value={role} onValueChange={setRole}>
                  <SelectTrigger className="border-2 border-foreground rounded-none h-12 text-lg">
                    <SelectValue placeholder="选择身份" />
                  </SelectTrigger>
                  <SelectContent className="border-2 border-foreground rounded-none">
                    <SelectItem value="student">学生 (Student)</SelectItem>
                    <SelectItem value="delivery">配送员 (Delivery)</SelectItem>
                    <SelectItem value="admin">管理员 (Admin)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </>
          )}
          <div className="space-y-2">
            <label className="font-bold">登录账号</label>
            <Input 
              type="text" 
              value={username} 
              onChange={e => setUsername(e.target.value)} 
              required 
              placeholder="请输入账号"
              className="border-2 border-foreground rounded-none p-2 h-12 text-lg"
            />
          </div>
          <div className="space-y-2">
            <label className="font-bold">密码</label>
            <Input 
              type="password" 
              value={password} 
              onChange={e => setPassword(e.target.value)} 
              required 
              placeholder="••••••••"
              className="border-2 border-foreground rounded-none p-2 h-12 text-lg"
            />
          </div>
          
          <Button 
            type="submit" 
            className="w-full h-14 text-xl font-bold border-2 border-foreground retro-shadow retro-btn mt-6"
            disabled={loading}
          >
            {loading ? "处理中..." : isLogin ? "登录系统" : "创建账号"}
          </Button>
        </form>

        <div className="mt-6 text-center">
          <button 
            type="button" 
            onClick={() => setIsLogin(!isLogin)}
            className="text-primary font-bold hover:underline"
          >
            {isLogin ? "没有账号？立即注册 >" : "已有账号？返回登录 >"}
          </button>
        </div>
      </div>
    </div>
  );
}
