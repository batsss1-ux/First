import { useState, useEffect } from "react";
import { MainLayout } from "@/components/layouts/MainLayout";
import { supabase } from "@/db/supabase";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { Truck, CheckCircle, Bell } from "lucide-react";

export default function Delivery() {
  const { user } = useAuth();
  const [orders, setOrders] = useState<any[]>([]);
  const [announcements, setAnnouncements] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchData() {
      if (!user) return;
      setLoading(true);
      const today = new Date().toISOString().split('T')[0];
      
      const [ordersRes, annRes] = await Promise.all([
        supabase.from("orders")
          .select(`*, users!orders_user_id_fkey(name, phone)`)
          .eq("delivery_person_id", user.id)
          .eq("status", "paid")
          .gte("target_date", today)
          .order("target_date", { ascending: true }),
        supabase.from('announcements')
          .select('*')
          .order('created_at', { ascending: false })
          .limit(3)
      ]);
      
      if (ordersRes.data) setOrders(ordersRes.data);
      if (annRes.data) setAnnouncements(annRes.data);
      
      setLoading(false);
    }
    
    fetchData();
  }, [user]);

  const fetchOrders = async () => {
    if (!user) return;
    const today = new Date().toISOString().split('T')[0];
    const { data } = await supabase.from("orders")
      .select(`*, users!orders_user_id_fkey(name, phone)`)
      .eq("delivery_person_id", user.id)
      .eq("status", "paid")
      .gte("target_date", today)
      .order("target_date", { ascending: true });
    if (data) setOrders(data);
  };

  const updateStatus = async (orderId: string, status: string) => {
    try {
      const { error } = await supabase.from("orders").update({ delivery_status: status }).eq("id", orderId);
      if (error) throw error;
      toast.success("状态已更新！");
      fetchOrders();
    } catch (error: any) {
      toast.error("更新失败");
    }
  };

  return (
    <MainLayout role="delivery">
      <div className="space-y-6">
        <h1 className="text-3xl font-bold border-b-4 border-foreground pb-2">我的配送任务</h1>
        
        {announcements.length > 0 && (
          <div className="bg-accent/20 p-4 border-4 border-accent retro-shadow mb-6">
            <h2 className="text-lg font-bold mb-2 flex items-center text-accent-foreground">
              <Bell className="w-5 h-5 mr-2" /> 最新公告
            </h2>
            <div className="space-y-2">
              {announcements.map((ann, idx) => (
                <div key={idx} className="border-b-2 border-accent/30 pb-2 last:border-0 last:pb-0">
                  <h3 className="font-bold">{ann.title}</h3>
                  <p className="text-sm mt-1">{ann.content}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {loading ? (
          <div className="text-center font-bold text-xl py-10">LOADING...</div>
        ) : orders.length === 0 ? (
          <div className="bg-card p-8 border-4 border-foreground retro-shadow text-center">
            <p className="text-xl font-bold text-muted-foreground">今天没有您的配送任务！</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {orders.map(order => (
              <div key={order.id} className="bg-card border-4 border-foreground retro-shadow flex flex-col h-full">
                <div className="p-4 bg-secondary text-secondary-foreground border-b-4 border-foreground">
                  <h3 className="text-xl font-bold uppercase">订单号：{order.order_number}</h3>
                </div>
                <div className="p-4 flex-1">
                  <p className="font-bold mb-2">客户：{order.users?.name}</p>
                  <p className="font-bold mb-2 text-muted-foreground">送餐日期：{order.target_date}</p>
                  <div className="my-4 border-2 border-foreground p-3 bg-muted/30">
                    <p className="font-bold">状态：
                      {order.delivery_status === 'pending' ? '待处理' : 
                       order.delivery_status === 'delivering' ? <span className="text-accent-foreground">配送中</span> : 
                       <span className="text-primary">已送达</span>}
                    </p>
                  </div>
                </div>
                <div className="p-4 pt-0 mt-auto flex gap-2">
                  {order.delivery_status === 'pending' && (
                    <Button className="flex-1 font-bold retro-btn border-2 border-foreground bg-accent text-accent-foreground" onClick={() => updateStatus(order.id, 'delivering')}>
                      <Truck className="w-5 h-5 mr-2" />
                      开始配送
                    </Button>
                  )}
                  {order.delivery_status === 'delivering' && (
                    <Button className="flex-1 font-bold retro-btn border-2 border-foreground bg-primary text-primary-foreground" onClick={() => updateStatus(order.id, 'delivered')}>
                      <CheckCircle className="w-5 h-5 mr-2" />
                      确认送达
                    </Button>
                  )}
                  {order.delivery_status === 'delivered' && (
                    <Button disabled onClick={() => {}} className="flex-1 font-bold retro-btn border-2 border-foreground bg-muted text-muted-foreground">
                      已完成
                    </Button>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </MainLayout>
  );
}
