import { useState, useEffect } from "react";
import { MainLayout } from "@/components/layouts/MainLayout";
import { supabase } from "@/db/supabase";
import { useAuth } from "@/contexts/AuthContext";

export default function StudentReport() {
  const { user, userRole } = useAuth();
  const [stats, setStats] = useState({ calories: 0, protein: 0, fat: 0, carbs: 0, count: 0 });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchData();
  }, [user]);

  const fetchData = async () => {
    if (!user) return;
    setLoading(true);
    // Fetch last 7 days paid orders
    const lastWeek = new Date();
    lastWeek.setDate(lastWeek.getDate() - 7);
    const { data } = await supabase
      .from("orders")
      .select("total_calories, total_protein, total_fat, total_carbs")
      .eq("user_id", user.id)
      .eq("status", "paid")
      .gte("target_date", lastWeek.toISOString().split('T')[0]);
    
    if (data) {
      const summary = data.reduce((acc, curr) => ({
        calories: acc.calories + (curr.total_calories || 0),
        protein: acc.protein + (curr.total_protein || 0),
        fat: acc.fat + (curr.total_fat || 0),
        carbs: acc.carbs + (curr.total_carbs || 0),
        count: acc.count + 1
      }), { calories: 0, protein: 0, fat: 0, carbs: 0, count: 0 });
      setStats(summary);
    }
    setLoading(false);
  };

  return (
    <MainLayout role={userRole as any}>
      <div className="space-y-6">
        <h1 className="text-3xl font-bold border-b-4 border-foreground pb-2">营养报表 (近7日)</h1>

        {loading ? (
          <div className="text-center font-bold text-xl py-10">LOADING...</div>
        ) : (
          <div className="space-y-6">
            <div className="bg-card p-6 border-4 border-foreground retro-shadow text-center">
              <h2 className="text-xl font-bold mb-2">已摄入餐数</h2>
              <p className="text-5xl font-bold text-primary">{stats.count}</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <div className="bg-card p-6 border-4 border-foreground retro-shadow text-center">
                <h3 className="text-lg font-bold mb-2 uppercase text-primary">热量总计</h3>
                <p className="text-3xl font-bold">{stats.calories} <span className="text-sm">kcal</span></p>
              </div>
              <div className="bg-card p-6 border-4 border-foreground retro-shadow text-center">
                <h3 className="text-lg font-bold mb-2 uppercase text-secondary">蛋白质</h3>
                <p className="text-3xl font-bold">{stats.protein.toFixed(1)} <span className="text-sm">g</span></p>
              </div>
              <div className="bg-card p-6 border-4 border-foreground retro-shadow text-center">
                <h3 className="text-lg font-bold mb-2 uppercase text-accent text-accent-foreground">脂肪</h3>
                <p className="text-3xl font-bold">{stats.fat.toFixed(1)} <span className="text-sm">g</span></p>
              </div>
              <div className="bg-card p-6 border-4 border-foreground retro-shadow text-center">
                <h3 className="text-lg font-bold mb-2 uppercase text-foreground">碳水</h3>
                <p className="text-3xl font-bold">{stats.carbs.toFixed(1)} <span className="text-sm">g</span></p>
              </div>
            </div>

            <div className="bg-muted p-6 border-4 border-foreground retro-shadow mt-6">
              <h3 className="text-xl font-bold mb-2">💡 健康分析建议</h3>
              {stats.count === 0 ? (
                <p className="font-bold text-muted-foreground">数据不足，无法生成建议。</p>
              ) : (
                <p className="font-bold leading-relaxed">
                  根据您过去 7 天的记录，平均每餐热量为 {(stats.calories / stats.count).toFixed(0)} kcal。
                  {stats.calories / stats.count > 800 ? " 热量摄入偏高，请注意增加运动量或选择清淡套餐。" : " 热量摄入适中，请继续保持健康的饮食习惯！"}
                </p>
              )}
            </div>
          </div>
        )}
      </div>
    </MainLayout>
  );
}
