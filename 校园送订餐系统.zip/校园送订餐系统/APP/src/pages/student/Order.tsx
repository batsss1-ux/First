import { useState, useEffect } from "react";
import { MainLayout } from "@/components/layouts/MainLayout";
import { supabase } from "@/db/supabase";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { toast } from "sonner";
import { Plus, Minus, ShoppingCart } from "lucide-react";
import { useNavigate } from "react-router-dom";

export default function StudentOrder() {
  const { user, userRole } = useAuth();
  const navigate = useNavigate();
  const [menus, setMenus] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  // Customization dialog
  const [orderOpen, setOrderOpen] = useState(false);
  const [selectedMenu, setSelectedMenu] = useState<any>(null);
  const [dishQuantities, setDishQuantities] = useState<Record<string, number>>({});

  useEffect(() => {
    fetchAvailableMenus();
  }, []);

  const fetchAvailableMenus = async () => {
    setLoading(true);
    const today = new Date().toISOString().split('T')[0];
    const { data, error } = await supabase
      .from("menus")
      .select(`
        *,
        menu_dishes(
          dish_id,
          dishes(*)
        )
      `)
      .gte("date", today)
      .order("date", { ascending: true });
    
    if (!error && data) setMenus(data);
    setLoading(false);
  };

  const openOrderDialog = (menu: any) => {
    setSelectedMenu(menu);
    const initialQtys: Record<string, number> = {};
    menu.menu_dishes.forEach((md: any) => {
      initialQtys[md.dish_id] = 1; // Default quantity is 1
    });
    setDishQuantities(initialQtys);
    setOrderOpen(true);
  };

  const updateQuantity = (dishId: string, delta: number) => {
    setDishQuantities(prev => {
      const current = prev[dishId] || 0;
      const next = Math.max(0, current + delta);
      return { ...prev, [dishId]: next };
    });
  };

  const submitOrder = async () => {
    if (!user) return;
    
    const selectedDishes = Object.entries(dishQuantities).filter(([_, qty]) => qty > 0);
    if (selectedDishes.length === 0) {
      toast.error("您至少需要选择一个菜品！");
      return;
    }

    try {
      // Calculate totals
      let totalCals = 0, totalPro = 0, totalFat = 0, totalCarbs = 0, totalPrice = 0;
      selectedDishes.forEach(([dishId, qty]) => {
        const dishInfo = selectedMenu.menu_dishes.find((md: any) => md.dish_id === dishId)?.dishes;
        if (dishInfo) {
          totalCals += dishInfo.calories * qty;
          totalPro += dishInfo.protein * qty;
          totalFat += dishInfo.fat * qty;
          totalCarbs += dishInfo.carbs * qty;
          totalPrice += Number(dishInfo.price || 0) * qty;
        }
      });

      // Insert Order
      const { data: orderData, error: orderError } = await supabase.from("orders").insert([{
        user_id: user.id,
        student_id: userRole === 'parent' ? user.id : user.id, // simplified mapping for demo
        menu_id: selectedMenu.id,
        target_date: selectedMenu.date,
        status: "pending",
        total_calories: totalCals,
        total_protein: totalPro,
        total_fat: totalFat,
        total_carbs: totalCarbs,
        total_price: totalPrice
      }]).select().single();

      if (orderError) throw orderError;

      // Insert Order Dishes
      const orderDishesToInsert = selectedDishes.map(([dishId, qty]) => ({
        order_id: orderData.id,
        dish_id: dishId,
        quantity: qty
      }));

      const { error: odError } = await supabase.from("order_dishes").insert(orderDishesToInsert);
      if (odError) throw odError;

      toast.success("订单提交成功！请前往支付。");
      setOrderOpen(false);
      navigate(`/${userRole}/history`);

    } catch (error: any) {
      toast.error(error.message || "下单失败");
    }
  };

  return (
    <MainLayout role={userRole as any}>
      <div className="space-y-6">
        <h1 className="text-3xl font-bold border-b-4 border-foreground pb-2">今日与未来菜单</h1>
        
        {loading ? (
          <div className="text-center font-bold text-xl py-10">LOADING...</div>
        ) : menus.length === 0 ? (
          <div className="bg-card p-8 border-4 border-foreground retro-shadow text-center">
            <p className="text-xl font-bold text-muted-foreground">暂无可订餐菜单，敬请期待！</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {menus.map(menu => (
              <div key={menu.id} className="bg-card border-4 border-foreground retro-shadow flex flex-col h-full">
                <div className="p-4 bg-primary text-primary-foreground border-b-4 border-foreground">
                  <h3 className="text-xl font-bold uppercase">{menu.name}</h3>
                  <p className="font-bold opacity-80">{menu.date} | {menu.type === 'daily' ? '每日特供' : '本周经典'}</p>
                </div>
                <div className="p-4 flex-1">
                  <p className="font-bold mb-2">包含菜品：</p>
                  <ul className="space-y-2 mb-4">
                    {menu.menu_dishes?.map((md: any) => (
                      <li key={md.dish_id} className="flex items-center gap-2 text-sm font-bold">
                        <div className="w-2 h-2 bg-foreground" />
                        {md.dishes?.name}
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="p-4 pt-0 mt-auto">
                  <Button 
                    className="w-full font-bold retro-btn border-2 border-foreground"
                    onClick={() => openOrderDialog(menu)}
                  >
                    <ShoppingCart className="w-5 h-5 mr-2" />
                    定制并下单
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}

        <Dialog open={orderOpen} onOpenChange={setOrderOpen}>
          <DialogContent className="border-4 border-foreground retro-shadow max-w-[calc(100%-2rem)] md:max-w-lg bg-card p-6 max-h-[90dvh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="text-2xl font-bold uppercase">定制套餐</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 mt-4">
              <div className="bg-muted/30 p-4 border-2 border-foreground">
                <h4 className="font-bold text-lg mb-2">{selectedMenu?.name}</h4>
                <p className="text-sm font-bold text-muted-foreground">{selectedMenu?.date}</p>
              </div>
              
              <div className="space-y-3">
                <p className="font-bold border-b-2 border-foreground pb-2">调整菜品份数：</p>
                {selectedMenu?.menu_dishes?.map((md: any) => {
                  const dish = md.dishes;
                  const qty = dishQuantities[dish.id] || 0;
                  return (
                    <div key={dish.id} className="flex items-center justify-between bg-background border-2 border-foreground p-3">
                      <div className="flex items-center gap-3">
                        <div className="w-12 h-12 border-2 border-foreground bg-muted shrink-0">
                          {dish.image_url && <img src={dish.image_url} className="w-full h-full object-cover" style={{ imageRendering: 'pixelated' }} />}
                        </div>
                        <div>
                          <p className="font-bold">{dish.name}</p>
                          <p className="text-xs text-muted-foreground font-bold">
                            ¥{Number(dish.price).toFixed(2)} | {dish.calories} kcal
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-3 shrink-0">
                        <Button size="icon" variant="outline" className="h-8 w-8 retro-btn border-2 border-foreground" onClick={() => updateQuantity(dish.id, -1)}>
                          <Minus className="h-4 w-4" />
                        </Button>
                        <span className="font-bold w-4 text-center">{qty}</span>
                        <Button size="icon" variant="outline" className="h-8 w-8 retro-btn border-2 border-foreground" onClick={() => updateQuantity(dish.id, 1)}>
                          <Plus className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  );
                })}
              </div>

              <div className="bg-primary/10 p-4 border-2 border-primary mt-4 flex justify-between items-center">
                <span className="font-bold text-lg">合计金额：</span>
                <span className="font-bold text-2xl text-primary">
                  ¥{Object.entries(dishQuantities).reduce((sum, [dishId, qty]) => {
                    const dish = selectedMenu?.menu_dishes?.find((md: any) => md.dish_id === dishId)?.dishes;
                    return sum + (Number(dish?.price || 0) * qty);
                  }, 0).toFixed(2)}
                </span>
              </div>

              <Button onClick={submitOrder} className="w-full font-bold retro-btn retro-shadow border-2 border-foreground mt-4 h-12 text-lg">
                确认下单
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </MainLayout>
  );
}
