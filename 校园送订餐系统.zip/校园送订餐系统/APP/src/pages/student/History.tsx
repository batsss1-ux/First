import { useState, useEffect } from "react";
import { MainLayout } from "@/components/layouts/MainLayout";
import { supabase } from "@/db/supabase";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { CreditCard, UtensilsCrossed, Truck, Star } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";

export default function StudentHistory() {
  const { user, userRole } = useAuth();
  const [orders, setOrders] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [reviewOpen, setReviewOpen] = useState(false);
  const [reviewOrder, setReviewOrder] = useState<any>(null);
  const [rating, setRating] = useState(5);
  const [review, setReview] = useState("");

  useEffect(() => {
    fetchOrders();
  }, [user]);

  const fetchOrders = async () => {
    if (!user) return;
    setLoading(true);
    const { data, error } = await supabase
      .from("orders")
      .select(`
        *,
        menus(name),
        order_dishes(
          quantity,
          dishes(name)
        )
      `)
      .eq("user_id", user.id)
      .order("created_at", { ascending: false });
    
    if (!error && data) setOrders(data);
    setLoading(false);
  };

  const handlePay = async (orderId: string) => {
    try {
      // 获取所有配送员
      const { data: deliveryPersons } = await supabase.from('users').select('id').eq('role', 'delivery');
      
      let updatePayload: any = { status: 'paid' };
      
      // 随机分配一个配送员
      if (deliveryPersons && deliveryPersons.length > 0) {
        const randomPerson = deliveryPersons[Math.floor(Math.random() * deliveryPersons.length)];
        updatePayload.delivery_person_id = randomPerson.id;
      }

      const { error } = await supabase.from("orders").update(updatePayload).eq("id", orderId);
      if (error) throw error;
      
      toast.success("支付成功！系统已自动为您分配配送员。");
      fetchOrders();
    } catch (error: any) {
      toast.error(error.message || "支付失败");
    }
  };

  const handleCancel = async (orderId: string) => {
    if (!confirm("确定取消此订单吗？")) return;
    try {
      const { error } = await supabase.from("orders").update({ status: 'cancelled' }).eq("id", orderId);
      if (error) throw error;
      toast.success("订单已取消");
      fetchOrders();
    } catch (error: any) {
      toast.error("取消失败");
    }
  };

  const handleConfirmReceipt = (order: any) => {
    setReviewOrder(order);
    setRating(5);
    setReview("");
    setReviewOpen(true);
  };

  const submitReview = async () => {
    try {
      const { error } = await supabase.from("orders").update({ 
        status: 'completed',
        rating: rating,
        review: review
      }).eq("id", reviewOrder.id);
      
      if (error) throw error;
      toast.success("评价成功，已确认收货！");
      setReviewOpen(false);
      fetchOrders();
    } catch (error: any) {
      toast.error("评价失败");
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'pending': return <span className="bg-muted text-foreground border-2 border-foreground px-2 py-1 text-xs">待支付</span>;
      case 'paid': return <span className="bg-primary text-primary-foreground border-2 border-foreground px-2 py-1 text-xs">已支付</span>;
      case 'completed': return <span className="bg-accent text-accent-foreground border-2 border-foreground px-2 py-1 text-xs">已完成</span>;
      case 'refunded': return <span className="bg-secondary text-secondary-foreground border-2 border-foreground px-2 py-1 text-xs">已退款</span>;
      case 'cancelled': return <span className="bg-destructive text-destructive-foreground border-2 border-foreground px-2 py-1 text-xs">已取消</span>;
      default: return null;
    }
  };

  const getDeliveryBadge = (status: string) => {
    switch (status) {
      case 'pending': return <span className="text-muted-foreground">待处理</span>;
      case 'delivering': return <span className="text-accent-foreground font-bold">配送中</span>;
      case 'delivered': return <span className="text-primary font-bold">已送达</span>;
      default: return null;
    }
  };

  return (
    <MainLayout role={userRole as any}>
      <div className="space-y-6">
        <h1 className="text-3xl font-bold border-b-4 border-foreground pb-2">我的订单</h1>
        
        {loading ? (
          <div className="text-center font-bold text-xl py-10">LOADING...</div>
        ) : orders.length === 0 ? (
          <div className="bg-card p-8 border-4 border-foreground retro-shadow text-center">
            <p className="text-xl font-bold text-muted-foreground">暂无订单记录</p>
          </div>
        ) : (
          <div className="space-y-4">
            {orders.map(order => (
              <div key={order.id} className="bg-card border-4 border-foreground retro-shadow flex flex-col md:flex-row">
                <div className="p-4 bg-muted border-b-4 md:border-b-0 md:border-r-4 border-foreground flex-shrink-0 md:w-48 flex flex-col justify-center items-center text-center">
                  <p className="font-bold text-lg mb-1">{order.target_date}</p>
                  <div className="mb-2">{getStatusBadge(order.status)}</div>
                  <p className="text-xs font-bold text-muted-foreground">No. {order.order_number}</p>
                  <p className="text-lg font-bold text-primary mt-2">¥{Number(order.total_price || 0).toFixed(2)}</p>
                </div>
                
                <div className="p-4 flex-1 flex flex-col justify-between">
                  <div>
                    <h3 className="text-xl font-bold uppercase mb-2 flex items-center">
                      <UtensilsCrossed className="w-5 h-5 mr-2" />
                      {order.menus?.name || '自定义套餐'}
                    </h3>
                    <div className="text-sm font-bold space-y-1 mb-4">
                      {order.order_dishes?.map((od: any, idx: number) => (
                        <div key={idx} className="flex justify-between border-b-2 border-muted pb-1">
                          <span>{od.dishes?.name}</span>
                          <span>x{od.quantity}</span>
                        </div>
                      ))}
                    </div>
                    <div className="flex items-center gap-2 text-sm font-bold bg-muted/30 p-2 border-2 border-foreground mb-4">
                      <Truck className="w-4 h-4" />
                      <span>配送状态: {getDeliveryBadge(order.delivery_status)}</span>
                    </div>
                  </div>
                  
                  <div className="flex justify-end gap-2 mt-2">
                    {order.status === 'pending' && (
                      <>
                        <Button variant="outline" className="border-2 border-foreground retro-btn font-bold" onClick={() => handleCancel(order.id)}>取消</Button>
                        <Button className="border-2 border-foreground retro-btn retro-shadow font-bold bg-primary text-primary-foreground" onClick={() => handlePay(order.id)}>
                          <CreditCard className="w-4 h-4 mr-2" /> 立即支付
                        </Button>
                      </>
                    )}
                    {order.status === 'paid' && order.delivery_status === 'delivered' && (
                      <Button className="border-2 border-foreground retro-btn retro-shadow font-bold bg-accent text-accent-foreground" onClick={() => handleConfirmReceipt(order)}>
                        确认收货并评价
                      </Button>
                    )}
                  </div>
                  
                  {order.status === 'completed' && order.rating && (
                    <div className="mt-4 p-3 bg-muted/50 border-2 border-foreground text-sm font-bold">
                      <div className="flex items-center gap-1 text-accent mb-1">
                        评分: {Array.from({ length: 5 }).map((_, i) => (
                          <Star key={i} className={`w-4 h-4 ${i < order.rating ? 'fill-accent text-accent' : 'text-muted-foreground'}`} />
                        ))}
                      </div>
                      <p className="text-muted-foreground">{order.review || '未填写文字评价'}</p>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <Dialog open={reviewOpen} onOpenChange={setReviewOpen}>
        <DialogContent className="border-4 border-foreground rounded-none retro-shadow bg-card max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader>
            <DialogTitle className="text-2xl font-bold border-b-4 border-foreground pb-2">确认收货与评价</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div>
              <p className="font-bold mb-2">为本次用餐打分：</p>
              <div className="flex gap-2">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    key={star}
                    type="button"
                    onClick={() => setRating(star)}
                    className="focus:outline-none"
                  >
                    <Star className={`w-8 h-8 ${star <= rating ? 'fill-accent text-accent' : 'text-muted-foreground'}`} />
                  </button>
                ))}
              </div>
            </div>
            <div>
              <p className="font-bold mb-2">评价内容（可选）：</p>
              <Textarea 
                placeholder="菜品味道如何？配送服务满意吗？" 
                value={review}
                onChange={(e) => setReview(e.target.value)}
                className="border-2 border-foreground rounded-none min-h-[100px]"
              />
            </div>
          </div>
          <DialogFooter className="flex-row justify-end gap-2">
            <Button variant="outline" className="border-2 border-foreground retro-btn font-bold" onClick={() => setReviewOpen(false)}>
              取消
            </Button>
            <Button className="border-2 border-foreground retro-btn retro-shadow font-bold bg-primary text-primary-foreground" onClick={submitReview}>
              提交评价
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </MainLayout>
  );
}
