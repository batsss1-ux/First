import { useState, useEffect } from "react";
import { MainLayout } from "@/components/layouts/MainLayout";
import { supabase } from "@/db/supabase";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";

export default function AdminDelivery() {
  const [orders, setOrders] = useState<any[]>([]);
  const [deliveryPersons, setDeliveryPersons] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    setLoading(true);
    const today = new Date().toISOString().split('T')[0];
    
    // Fetch today's paid orders
    const { data: orderData } = await supabase
      .from("orders")
      .select(`*, users!orders_user_id_fkey(name)`)
      .eq("status", "paid")
      .gte("target_date", today)
      .order("target_date", { ascending: true });
    if (orderData) setOrders(orderData);

    // Fetch delivery persons
    const { data: dpData } = await supabase.from("users").select("*").eq("role", "delivery");
    if (dpData) setDeliveryPersons(dpData);

    setLoading(false);
  };

  const handleAssign = async (orderId: string, personId: string) => {
    try {
      const { error } = await supabase.from("orders").update({ delivery_person_id: personId }).eq("id", orderId);
      if (error) throw error;
      toast.success("分配成功！");
      fetchData();
    } catch (error: any) {
      toast.error("分配失败");
    }
  };

  return (
    <MainLayout role="admin">
      <div className="space-y-6">
        <h1 className="text-3xl font-bold border-b-4 border-foreground pb-2">配送管理</h1>

        {loading ? (
          <div className="text-center font-bold text-xl py-10">LOADING...</div>
        ) : (
          <div className="w-full max-w-full overflow-x-auto bg-card border-4 border-foreground retro-shadow">
            <table className="w-full text-left border-collapse min-w-max">
              <thead className="bg-primary text-primary-foreground border-b-4 border-foreground">
                <tr>
                  <th className="p-4 font-bold border-r-4 border-foreground whitespace-nowrap">订单号</th>
                  <th className="p-4 font-bold border-r-4 border-foreground whitespace-nowrap">送餐日期</th>
                  <th className="p-4 font-bold border-r-4 border-foreground whitespace-nowrap">客户</th>
                  <th className="p-4 font-bold border-r-4 border-foreground whitespace-nowrap">当前状态</th>
                  <th className="p-4 font-bold whitespace-nowrap">分配配送员</th>
                </tr>
              </thead>
              <tbody>
                {orders.map((order) => (
                  <tr key={order.id} className="border-b-4 border-foreground last:border-b-0 hover:bg-muted/50 transition-colors">
                    <td className="p-4 font-bold border-r-4 border-foreground whitespace-nowrap">{order.order_number}</td>
                    <td className="p-4 font-bold border-r-4 border-foreground whitespace-nowrap">{order.target_date}</td>
                    <td className="p-4 font-bold border-r-4 border-foreground whitespace-nowrap">{order.users?.name}</td>
                    <td className="p-4 font-bold border-r-4 border-foreground whitespace-nowrap">
                      {order.delivery_status === 'pending' ? '待处理' : order.delivery_status === 'delivering' ? '配送中' : '已送达'}
                    </td>
                    <td className="p-4 font-bold whitespace-nowrap">
                      {order.delivery_status === 'pending' ? (
                        <Select 
                          value={order.delivery_person_id || ""} 
                          onValueChange={(val) => handleAssign(order.id, val)}
                        >
                          <SelectTrigger className="border-2 border-foreground w-40">
                            <SelectValue placeholder="未分配" />
                          </SelectTrigger>
                          <SelectContent className="border-2 border-foreground">
                            {deliveryPersons.map(dp => (
                              <SelectItem key={dp.id} value={dp.id}>{dp.name}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      ) : (
                        <span className="text-muted-foreground ml-2">不可更改</span>
                      )}
                    </td>
                  </tr>
                ))}
                {orders.length === 0 && (
                  <tr>
                    <td colSpan={5} className="p-8 text-center font-bold text-muted-foreground">暂无需要配送的订单</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </MainLayout>
  );
}
