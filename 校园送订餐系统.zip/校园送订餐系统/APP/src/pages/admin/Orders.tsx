import { useState, useEffect } from "react";
import { MainLayout } from "@/components/layouts/MainLayout";
import { supabase } from "@/db/supabase";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { Search, Star } from "lucide-react";
import { Input } from "@/components/ui/input";

export default function AdminOrders() {
  const [orders, setOrders] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");

  useEffect(() => {
    fetchOrders();
  }, []);

  const fetchOrders = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from("orders")
      .select(`
        *,
        users!orders_user_id_fkey(name),
        menus(name)
      `)
      .order("created_at", { ascending: false });
    
    if (!error && data) setOrders(data);
    setLoading(false);
  };

  const handleRefund = async (orderId: string) => {
    if (!confirm("确定为该订单退款吗？")) return;
    try {
      const { error } = await supabase.from("orders").update({ status: 'refunded' }).eq("id", orderId);
      if (error) throw error;
      toast.success("退款成功！");
      fetchOrders();
    } catch (error: any) {
      toast.error("退款失败");
    }
  };

  const filteredOrders = orders.filter(o => 
    o.order_number.includes(search) || 
    (o.users?.name && o.users.name.includes(search))
  );

  return (
    <MainLayout role="admin">
      <div className="space-y-6">
        <h1 className="text-3xl font-bold border-b-4 border-foreground pb-2">订单管理</h1>
        
        <div className="flex gap-2 mb-6">
          <div className="relative flex-1 max-w-sm">
            <Search className="absolute left-3 top-3 w-5 h-5 text-muted-foreground" />
            <Input 
              placeholder="搜索订单号或用户名..." 
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="pl-10 border-2 border-foreground h-12 font-bold"
            />
          </div>
        </div>

        {loading ? (
          <div className="text-center font-bold text-xl py-10">LOADING...</div>
        ) : (
          <div className="w-full max-w-full overflow-x-auto bg-card border-4 border-foreground retro-shadow">
            <table className="w-full text-left border-collapse min-w-max">
              <thead className="bg-primary text-primary-foreground border-b-4 border-foreground">
                <tr>
                  <th className="p-4 font-bold border-r-4 border-foreground whitespace-nowrap">订单号</th>
                  <th className="p-4 font-bold border-r-4 border-foreground whitespace-nowrap">下单人</th>
                  <th className="p-4 font-bold border-r-4 border-foreground whitespace-nowrap">目标日期</th>
                  <th className="p-4 font-bold border-r-4 border-foreground whitespace-nowrap">套餐</th>
                  <th className="p-4 font-bold border-r-4 border-foreground whitespace-nowrap">支付状态</th>
                  <th className="p-4 font-bold border-r-4 border-foreground whitespace-nowrap">配送状态</th>
                  <th className="p-4 font-bold border-r-4 border-foreground whitespace-nowrap">评价</th>
                  <th className="p-4 font-bold whitespace-nowrap">操作</th>
                </tr>
              </thead>
              <tbody>
                {filteredOrders.map((order) => (
                  <tr key={order.id} className="border-b-4 border-foreground last:border-b-0 hover:bg-muted/50 transition-colors">
                    <td className="p-4 font-bold border-r-4 border-foreground whitespace-nowrap">{order.order_number}</td>
                    <td className="p-4 font-bold border-r-4 border-foreground whitespace-nowrap">{order.users?.name || '未知用户'}</td>
                    <td className="p-4 font-bold border-r-4 border-foreground whitespace-nowrap">{order.target_date}</td>
                    <td className="p-4 font-bold border-r-4 border-foreground whitespace-nowrap">{order.menus?.name || '自定义'}</td>
                    <td className="p-4 font-bold border-r-4 border-foreground whitespace-nowrap">
                      {order.status === 'paid' ? <span className="text-primary">已支付</span> : order.status === 'completed' ? <span className="text-accent">已完成</span> : order.status === 'pending' ? <span className="text-muted-foreground">待支付</span> : order.status === 'refunded' ? <span className="text-secondary">已退款</span> : <span className="text-destructive">已取消</span>}
                    </td>
                    <td className="p-4 font-bold border-r-4 border-foreground whitespace-nowrap">
                      {order.delivery_status === 'pending' ? '待处理' : order.delivery_status === 'delivering' ? '配送中' : '已送达'}
                    </td>
                    <td className="p-4 font-bold border-r-4 border-foreground min-w-[150px]">
                      {order.status === 'completed' && order.rating ? (
                        <div className="text-sm">
                          <div className="flex items-center text-accent mb-1">
                            {Array.from({ length: 5 }).map((_, i) => (
                              <Star key={i} className={`w-3 h-3 ${i < order.rating ? 'fill-accent' : 'text-muted-foreground fill-none'}`} />
                            ))}
                          </div>
                          {order.review && <div className="text-muted-foreground truncate max-w-[150px]" title={order.review}>{order.review}</div>}
                        </div>
                      ) : (
                        <span className="text-muted-foreground text-sm font-normal">暂无</span>
                      )}
                    </td>
                    <td className="p-4 font-bold whitespace-nowrap">
                      {order.status === 'paid' && (
                        <Button size="sm" variant="outline" className="border-2 border-foreground retro-btn text-destructive hover:text-destructive" onClick={() => handleRefund(order.id)}>
                          退款
                        </Button>
                      )}
                    </td>
                  </tr>
                ))}
                {filteredOrders.length === 0 && (
                  <tr>
                    <td colSpan={8} className="p-8 text-center font-bold text-muted-foreground">暂无订单</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </MainLayout>
  );
}
