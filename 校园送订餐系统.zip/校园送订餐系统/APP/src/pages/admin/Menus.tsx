import { useState, useEffect } from "react";
import { MainLayout } from "@/components/layouts/MainLayout";
import { supabase } from "@/db/supabase";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import { Plus, Trash2, Edit } from "lucide-react";

export default function AdminMenus() {
  const [activeTab, setActiveTab] = useState<"dishes" | "menus">("menus");
  const [dishes, setDishes] = useState<any[]>([]);
  const [menus, setMenus] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  // Dialog states for Dish
  const [dishOpen, setDishOpen] = useState(false);
  const [dishForm, setDishForm] = useState({ id: "", name: "", image_url: "", calories: 0, protein: 0, fat: 0, carbs: 0, price: 10 });

  // Dialog states for Menu
  const [menuOpen, setMenuOpen] = useState(false);
  const [menuForm, setMenuForm] = useState<{ id: string, name: string, date: string, type: string, selectedDishes: string[] }>({ 
    id: "", name: "", date: new Date().toISOString().split('T')[0], type: "daily", selectedDishes: [] 
  });

  useEffect(() => {
    fetchDishes();
    fetchMenus();
  }, []);

  const fetchDishes = async () => {
    const { data, error } = await supabase.from("dishes").select("*").order("created_at", { ascending: false });
    if (!error && data) setDishes(data);
  };

  const fetchMenus = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from("menus")
      .select(`
        *,
        menu_dishes(
          dish_id,
          dishes(*)
        )
      `)
      .order("date", { ascending: false });
    if (!error && data) setMenus(data);
    setLoading(false);
  };

  // Dish logic
  const handleSaveDish = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (dishForm.id) {
        const { error } = await supabase.from("dishes").update(dishForm).eq("id", dishForm.id);
        if (error) throw error;
        toast.success("菜品已更新");
      } else {
        const { id, ...newDish } = dishForm;
        const { error } = await supabase.from("dishes").insert([newDish]);
        if (error) throw error;
        toast.success("菜品已添加");
      }
      setDishOpen(false);
      fetchDishes();
    } catch (error: any) {
      toast.error(error.message || "操作失败");
    }
  };

  const handleDeleteDish = async (id: string) => {
    if (!confirm("确定删除该菜品吗？")) return;
    const { error } = await supabase.from("dishes").delete().eq("id", id);
    if (!error) {
      toast.success("删除成功");
      fetchDishes();
    }
  };

  const openDishDialog = (dish?: any) => {
    if (dish) setDishForm(dish);
    else setDishForm({ id: "", name: "", image_url: "", calories: 0, protein: 0, fat: 0, carbs: 0, price: 10 });
    setDishOpen(true);
  };

  // Menu logic
  const handleSaveMenu = async (e: React.FormEvent) => {
    e.preventDefault();
    if (menuForm.selectedDishes.length === 0) {
      toast.error("请至少选择一个菜品");
      return;
    }

    try {
      let currentMenuId = menuForm.id;
      if (menuForm.id) {
        const { error } = await supabase.from("menus").update({
          name: menuForm.name, date: menuForm.date, type: menuForm.type
        }).eq("id", menuForm.id);
        if (error) throw error;
        
        // Update menu_dishes (simple way: delete all and insert)
        await supabase.from("menu_dishes").delete().eq("menu_id", menuForm.id);
      } else {
        const { data, error } = await supabase.from("menus").insert([{
          name: menuForm.name, date: menuForm.date, type: menuForm.type
        }]).select().single();
        if (error) throw error;
        currentMenuId = data.id;
      }

      const dishInserts = menuForm.selectedDishes.map(dishId => ({
        menu_id: currentMenuId,
        dish_id: dishId
      }));
      const { error: dError } = await supabase.from("menu_dishes").insert(dishInserts);
      if (dError) throw dError;

      toast.success("套餐已保存");
      setMenuOpen(false);
      fetchMenus();
    } catch (error: any) {
      toast.error(error.message || "保存失败");
    }
  };

  const handleDeleteMenu = async (id: string) => {
    if (!confirm("确定删除该套餐吗？")) return;
    const { error } = await supabase.from("menus").delete().eq("id", id);
    if (!error) {
      toast.success("删除成功");
      fetchMenus();
    }
  };

  const openMenuDialog = (menu?: any) => {
    if (menu) {
      setMenuForm({
        id: menu.id,
        name: menu.name,
        date: menu.date,
        type: menu.type,
        selectedDishes: menu.menu_dishes.map((md: any) => md.dish_id)
      });
    } else {
      setMenuForm({ 
        id: "", name: "", date: new Date().toISOString().split('T')[0], type: "daily", selectedDishes: [] 
      });
    }
    setMenuOpen(true);
  };

  const toggleDishSelect = (dishId: string) => {
    setMenuForm(prev => ({
      ...prev,
      selectedDishes: prev.selectedDishes.includes(dishId)
        ? prev.selectedDishes.filter(id => id !== dishId)
        : [...prev.selectedDishes, dishId]
    }));
  };

  return (
    <MainLayout role="admin">
      <div className="space-y-6">
        <div className="flex flex-col md:flex-row justify-between items-center border-b-4 border-foreground pb-4 gap-4">
          <h1 className="text-3xl font-bold">菜单与菜品管理</h1>
          <div className="flex gap-2">
            <Button 
              variant={activeTab === "dishes" ? "default" : "outline"}
              className={`retro-shadow font-bold ${activeTab === "dishes" ? "border-foreground border-2" : "border-2 border-foreground"}`}
              onClick={() => setActiveTab("dishes")}
            >
              菜品库
            </Button>
            <Button 
              variant={activeTab === "menus" ? "default" : "outline"}
              className={`retro-shadow font-bold ${activeTab === "menus" ? "border-foreground border-2" : "border-2 border-foreground"}`}
              onClick={() => setActiveTab("menus")}
            >
              套餐安排
            </Button>
          </div>
        </div>

        {activeTab === "dishes" && (
          <div className="space-y-4">
            <div className="flex justify-end">
              <Dialog open={dishOpen} onOpenChange={setDishOpen}>
                <DialogTrigger asChild>
                  <Button className="retro-btn retro-shadow border-2 border-foreground font-bold" onClick={() => openDishDialog()}>
                    <Plus className="w-5 h-5 mr-2" /> 新增菜品
                  </Button>
                </DialogTrigger>
                <DialogContent className="border-4 border-foreground retro-shadow max-w-[calc(100%-2rem)] md:max-w-lg bg-card p-6 max-h-[90dvh] overflow-y-auto">
                  <DialogHeader>
                    <DialogTitle className="text-2xl font-bold uppercase">{dishForm.id ? "编辑菜品" : "新增菜品"}</DialogTitle>
                  </DialogHeader>
                  <form onSubmit={handleSaveDish} className="space-y-4 mt-4">
                    <div>
                      <label className="font-bold">菜品名称</label>
                      <Input required value={dishForm.name} onChange={e => setDishForm({...dishForm, name: e.target.value})} className="border-2 border-foreground" />
                    </div>
                    <div>
                      <label className="font-bold">图片URL</label>
                      <Input value={dishForm.image_url} onChange={e => setDishForm({...dishForm, image_url: e.target.value})} className="border-2 border-foreground" />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="col-span-2">
                        <label className="font-bold text-primary">金额 (元)</label>
                        <Input type="number" step="0.1" required value={dishForm.price} onChange={e => setDishForm({...dishForm, price: Number(e.target.value)})} className="border-2 border-foreground border-primary" />
                      </div>
                      <div>
                        <label className="font-bold">热量 (kcal)</label>
                        <Input type="number" required value={dishForm.calories} onChange={e => setDishForm({...dishForm, calories: Number(e.target.value)})} className="border-2 border-foreground" />
                      </div>
                      <div>
                        <label className="font-bold">蛋白质 (g)</label>
                        <Input type="number" step="0.1" required value={dishForm.protein} onChange={e => setDishForm({...dishForm, protein: Number(e.target.value)})} className="border-2 border-foreground" />
                      </div>
                      <div>
                        <label className="font-bold">脂肪 (g)</label>
                        <Input type="number" step="0.1" required value={dishForm.fat} onChange={e => setDishForm({...dishForm, fat: Number(e.target.value)})} className="border-2 border-foreground" />
                      </div>
                      <div>
                        <label className="font-bold">碳水 (g)</label>
                        <Input type="number" step="0.1" required value={dishForm.carbs} onChange={e => setDishForm({...dishForm, carbs: Number(e.target.value)})} className="border-2 border-foreground" />
                      </div>
                    </div>
                    <Button type="submit" className="w-full font-bold retro-btn retro-shadow border-2 border-foreground mt-4">
                      保存菜品
                    </Button>
                  </form>
                </DialogContent>
              </Dialog>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {dishes.map(dish => (
                <div key={dish.id} className="bg-card border-4 border-foreground retro-shadow flex flex-col h-full">
                  <div className="h-48 border-b-4 border-foreground overflow-hidden bg-muted flex items-center justify-center">
                    {dish.image_url ? (
                      <img src={dish.image_url} alt={dish.name} className="w-full h-full object-cover retro-img" style={{ imageRendering: 'pixelated' }} />
                    ) : (
                      <span className="font-bold text-muted-foreground">NO IMAGE</span>
                    )}
                  </div>
                  <div className="p-4 flex-1 flex flex-col">
                    <div className="flex justify-between items-start mb-2">
                      <h3 className="text-xl font-bold uppercase truncate pr-2">{dish.name}</h3>
                      <span className="bg-primary text-primary-foreground font-bold px-2 py-1 border-2 border-foreground shrink-0 text-sm">
                        ¥{Number(dish.price).toFixed(2)}
                      </span>
                    </div>
                    <div className="grid grid-cols-2 gap-2 text-sm mb-4 font-bold flex-1">
                      <span className="text-primary">热量: {dish.calories}</span>
                      <span className="text-secondary">蛋白质: {dish.protein}</span>
                      <span className="text-accent">脂肪: {dish.fat}</span>
                      <span className="text-foreground">碳水: {dish.carbs}</span>
                    </div>
                    <div className="flex gap-2 shrink-0 mt-auto">
                      <Button variant="outline" className="flex-1 border-2 border-foreground retro-btn font-bold" onClick={() => openDishDialog(dish)}>
                        <Edit className="w-4 h-4 mr-2" /> 编辑
                      </Button>
                      <Button variant="destructive" className="flex-1 border-2 border-foreground retro-btn font-bold" onClick={() => handleDeleteDish(dish.id)}>
                        <Trash2 className="w-4 h-4 mr-2" /> 删除
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === "menus" && (
          <div className="space-y-4">
            <div className="flex justify-end">
              <Dialog open={menuOpen} onOpenChange={setMenuOpen}>
                <DialogTrigger asChild>
                  <Button className="retro-btn retro-shadow border-2 border-foreground font-bold" onClick={() => openMenuDialog()}>
                    <Plus className="w-5 h-5 mr-2" /> 新增套餐
                  </Button>
                </DialogTrigger>
                <DialogContent className="border-4 border-foreground retro-shadow max-w-[calc(100%-2rem)] md:max-w-lg bg-card p-6 max-h-[90dvh] overflow-y-auto">
                  <DialogHeader>
                    <DialogTitle className="text-2xl font-bold uppercase">{menuForm.id ? "编辑套餐" : "新增套餐"}</DialogTitle>
                  </DialogHeader>
                  <form onSubmit={handleSaveMenu} className="space-y-4 mt-4">
                    <div>
                      <label className="font-bold">套餐名称</label>
                      <Input required value={menuForm.name} onChange={e => setMenuForm({...menuForm, name: e.target.value})} className="border-2 border-foreground" />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="font-bold">提供日期</label>
                        <Input type="date" required value={menuForm.date} onChange={e => setMenuForm({...menuForm, date: e.target.value})} className="border-2 border-foreground" />
                      </div>
                      <div>
                        <label className="font-bold">类型</label>
                        <Select value={menuForm.type} onValueChange={v => setMenuForm({...menuForm, type: v})}>
                          <SelectTrigger className="border-2 border-foreground">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent className="border-2 border-foreground">
                            <SelectItem value="daily">每日特供</SelectItem>
                            <SelectItem value="weekly">本周经典</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    <div>
                      <label className="font-bold block mb-2">选择菜品 ({menuForm.selectedDishes.length})</label>
                      <div className="grid grid-cols-2 gap-2 max-h-48 overflow-y-auto p-2 border-2 border-foreground bg-muted/20">
                        {dishes.map(dish => (
                          <div 
                            key={dish.id} 
                            onClick={() => toggleDishSelect(dish.id)}
                            className={`p-2 border-2 cursor-pointer font-bold text-sm ${menuForm.selectedDishes.includes(dish.id) ? 'border-primary bg-primary/20 text-primary' : 'border-transparent hover:border-foreground/50'}`}
                          >
                            {dish.name}
                          </div>
                        ))}
                      </div>
                    </div>
                    <Button type="submit" className="w-full font-bold retro-btn retro-shadow border-2 border-foreground mt-4">
                      保存套餐
                    </Button>
                  </form>
                </DialogContent>
              </Dialog>
            </div>

            {loading ? (
              <div className="text-center font-bold text-xl py-10">LOADING...</div>
            ) : (
              <div className="w-full max-w-full overflow-x-auto bg-card border-4 border-foreground retro-shadow">
                <table className="w-full text-left border-collapse min-w-max">
                  <thead className="bg-primary text-primary-foreground border-b-4 border-foreground">
                    <tr>
                      <th className="p-4 font-bold border-r-4 border-foreground whitespace-nowrap">日期</th>
                      <th className="p-4 font-bold border-r-4 border-foreground whitespace-nowrap">类型</th>
                      <th className="p-4 font-bold border-r-4 border-foreground whitespace-nowrap">套餐名称</th>
                      <th className="p-4 font-bold border-r-4 border-foreground whitespace-nowrap">包含菜品</th>
                      <th className="p-4 font-bold whitespace-nowrap">操作</th>
                    </tr>
                  </thead>
                  <tbody>
                    {menus.map((menu) => (
                      <tr key={menu.id} className="border-b-4 border-foreground last:border-b-0 hover:bg-muted/50 transition-colors">
                        <td className="p-4 font-bold border-r-4 border-foreground whitespace-nowrap">{menu.date}</td>
                        <td className="p-4 font-bold border-r-4 border-foreground whitespace-nowrap">
                          {menu.type === 'daily' ? '每日特供' : '本周经典'}
                        </td>
                        <td className="p-4 font-bold border-r-4 border-foreground whitespace-nowrap">{menu.name}</td>
                        <td className="p-4 font-bold border-r-4 border-foreground">
                          <div className="flex flex-wrap gap-2 min-w-0">
                            {menu.menu_dishes?.map((md: any) => (
                              <span key={md.dish_id} className="px-2 py-1 bg-secondary text-secondary-foreground border-2 border-foreground text-xs whitespace-nowrap">
                                {md.dishes?.name}
                              </span>
                            ))}
                          </div>
                        </td>
                        <td className="p-4 font-bold whitespace-nowrap">
                          <div className="flex gap-2">
                            <Button size="sm" variant="outline" className="border-2 border-foreground retro-btn" onClick={() => openMenuDialog(menu)}>
                              <Edit className="w-4 h-4" />
                            </Button>
                            <Button size="sm" variant="destructive" className="border-2 border-foreground retro-btn" onClick={() => handleDeleteMenu(menu.id)}>
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </td>
                      </tr>
                    ))}
                    {menus.length === 0 && (
                      <tr>
                        <td colSpan={5} className="p-8 text-center font-bold text-muted-foreground">暂无套餐安排</td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}
      </div>
    </MainLayout>
  );
}
