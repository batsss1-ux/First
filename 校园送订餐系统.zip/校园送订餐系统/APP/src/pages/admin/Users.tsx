import { useState, useEffect } from "react";
import { MainLayout } from "@/components/layouts/MainLayout";
import { supabase } from "@/db/supabase";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { Trash2 } from "lucide-react";

export default function AdminUsers() {
  const [users, setUsers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    setLoading(true);
    const { data } = await supabase.from("users").select("*").order("created_at", { ascending: false });
    if (data) setUsers(data);
    setLoading(false);
  };

  const handleDelete = async (id: string) => {
    if (!confirm("注意：这将永久删除该用户账号及关联数据！是否继续？")) return;
    try {
      const { error } = await supabase.rpc('delete_user_by_admin', { target_user_id: id });
      if (error) throw error;
      toast.success("账号删除成功");
      fetchData();
    } catch (error: any) {
      toast.error(error.message || "删除失败");
    }
  };

  return (
    <MainLayout role="admin">
      <div className="space-y-6">
        <h1 className="text-3xl font-bold border-b-4 border-foreground pb-2">用户管理</h1>

        {loading ? (
          <div className="text-center font-bold text-xl py-10">LOADING...</div>
        ) : (
          <div className="w-full max-w-full overflow-x-auto bg-card border-4 border-foreground retro-shadow">
            <table className="w-full text-left border-collapse min-w-max">
              <thead className="bg-primary text-primary-foreground border-b-4 border-foreground">
                <tr>
                  <th className="p-4 font-bold border-r-4 border-foreground whitespace-nowrap">姓名</th>
                  <th className="p-4 font-bold border-r-4 border-foreground whitespace-nowrap">角色</th>
                  <th className="p-4 font-bold border-r-4 border-foreground whitespace-nowrap">电话</th>
                  <th className="p-4 font-bold border-r-4 border-foreground whitespace-nowrap">注册时间</th>
                  <th className="p-4 font-bold whitespace-nowrap">操作</th>
                </tr>
              </thead>
              <tbody>
                {users.map((u) => (
                  <tr key={u.id} className="border-b-4 border-foreground last:border-b-0 hover:bg-muted/50 transition-colors">
                    <td className="p-4 font-bold border-r-4 border-foreground whitespace-nowrap">{u.name}</td>
                    <td className="p-4 font-bold border-r-4 border-foreground whitespace-nowrap">
                      {u.role === 'admin' ? '管理员' : u.role === 'student' ? '学生' : u.role === 'parent' ? '家长' : '配送员'}
                    </td>
                    <td className="p-4 font-bold border-r-4 border-foreground whitespace-nowrap">{u.phone || '-'}</td>
                    <td className="p-4 font-bold border-r-4 border-foreground whitespace-nowrap">{new Date(u.created_at).toLocaleDateString()}</td>
                    <td className="p-4 font-bold whitespace-nowrap">
                      <Button size="sm" variant="destructive" className="border-2 border-foreground retro-btn" onClick={() => handleDelete(u.id)}>
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </MainLayout>
  );
}
