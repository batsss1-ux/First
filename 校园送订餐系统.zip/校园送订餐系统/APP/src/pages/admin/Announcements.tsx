import { useState, useEffect } from "react";
import { MainLayout } from "@/components/layouts/MainLayout";
import { supabase } from "@/db/supabase";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { Plus, Trash2 } from "lucide-react";

export default function AdminAnnouncements() {
  const { user } = useAuth();
  const [announcements, setAnnouncements] = useState<any[]>([]);
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    setLoading(true);
    const { data } = await supabase.from("announcements").select("*, users!announcements_author_id_fkey(name)").order("created_at", { ascending: false });
    if (data) setAnnouncements(data);
    setLoading(false);
  };

  const handlePost = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    try {
      const { error } = await supabase.from("announcements").insert([{
        title, content, author_id: user.id
      }]);
      if (error) throw error;
      toast.success("发布成功！");
      setTitle("");
      setContent("");
      fetchData();
    } catch (error: any) {
      toast.error("发布失败");
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm("确定删除该公告吗？")) return;
    const { error } = await supabase.from("announcements").delete().eq("id", id);
    if (!error) {
      toast.success("删除成功");
      fetchData();
    }
  };

  return (
    <MainLayout role="admin">
      <div className="space-y-6">
        <h1 className="text-3xl font-bold border-b-4 border-foreground pb-2">公告管理</h1>

        <div className="bg-card p-6 border-4 border-foreground retro-shadow">
          <h2 className="text-xl font-bold mb-4 uppercase">发布新公告</h2>
          <form onSubmit={handlePost} className="space-y-4">
            <Input required placeholder="公告标题" value={title} onChange={e => setTitle(e.target.value)} className="border-2 border-foreground h-12 text-lg font-bold" />
            <Textarea required placeholder="公告内容" value={content} onChange={e => setContent(e.target.value)} className="border-2 border-foreground min-h-[120px] font-bold" />
            <Button type="submit" className="retro-btn border-2 border-foreground font-bold retro-shadow"><Plus className="w-5 h-5 mr-2" /> 发布公告</Button>
          </form>
        </div>

        <div className="space-y-4">
          <h2 className="text-xl font-bold uppercase mt-8">历史公告</h2>
          {loading ? (
            <div className="font-bold">LOADING...</div>
          ) : announcements.length === 0 ? (
            <p className="font-bold text-muted-foreground">暂无公告</p>
          ) : (
            announcements.map(a => (
              <div key={a.id} className="bg-card p-4 border-4 border-foreground retro-shadow flex justify-between items-start">
                <div>
                  <h3 className="text-xl font-bold">{a.title}</h3>
                  <p className="text-sm font-bold text-muted-foreground mb-2">
                    发布者: {a.users?.name || '管理员'} | 时间: {new Date(a.created_at).toLocaleString()}
                  </p>
                  <p className="font-bold whitespace-pre-wrap">{a.content}</p>
                </div>
                <Button variant="destructive" size="icon" className="retro-btn border-2 border-foreground shrink-0 ml-4" onClick={() => handleDelete(a.id)}>
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            ))
          )}
        </div>
      </div>
    </MainLayout>
  );
}
