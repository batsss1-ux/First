import { Routes, Route, Navigate } from "react-router-dom";
import { useAuth } from "./contexts/AuthContext";
import Login from "./pages/Login";
import Admin from "./pages/Admin";
import AdminMenus from "./pages/admin/Menus";
import AdminOrders from "./pages/admin/Orders";
import AdminDelivery from "./pages/admin/Delivery";
import AdminAnnouncements from "./pages/admin/Announcements";
import AdminUsers from "./pages/admin/Users";
import Student from "./pages/Student";
import StudentOrder from "./pages/student/Order";
import StudentHistory from "./pages/student/History";
import StudentReport from "./pages/student/Report";
import Delivery from "./pages/Delivery";

const ProtectedRoute = ({ children, allowedRoles }: { children: React.ReactNode, allowedRoles?: string[] }) => {
  const { user, userRole, loading } = useAuth();
  
  if (loading) return <div className="min-h-screen flex items-center justify-center bg-background retro-font font-bold text-2xl">LOADING...</div>;
  
  if (!user) return <Navigate to="/login" replace />;
  
  if (allowedRoles && userRole && !allowedRoles.includes(userRole)) {
    return <Navigate to={`/${userRole}`} replace />;
  }
  
  return <>{children}</>;
};

export default function App() {
  const { user, userRole, loading } = useAuth();

  if (loading) return <div className="min-h-screen flex items-center justify-center bg-background retro-font font-bold text-2xl">LOADING...</div>;

  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      
      <Route path="/admin" element={<ProtectedRoute allowedRoles={['admin']}><Admin /></ProtectedRoute>} />
      <Route path="/admin/menus" element={<ProtectedRoute allowedRoles={['admin']}><AdminMenus /></ProtectedRoute>} />
      <Route path="/admin/orders" element={<ProtectedRoute allowedRoles={['admin']}><AdminOrders /></ProtectedRoute>} />
      <Route path="/admin/delivery" element={<ProtectedRoute allowedRoles={['admin']}><AdminDelivery /></ProtectedRoute>} />
      <Route path="/admin/announcements" element={<ProtectedRoute allowedRoles={['admin']}><AdminAnnouncements /></ProtectedRoute>} />
      <Route path="/admin/users" element={<ProtectedRoute allowedRoles={['admin']}><AdminUsers /></ProtectedRoute>} />
      
      <Route path="/student" element={<ProtectedRoute allowedRoles={['student', 'parent']}><Student /></ProtectedRoute>} />
      <Route path="/student/order" element={<ProtectedRoute allowedRoles={['student', 'parent']}><StudentOrder /></ProtectedRoute>} />
      <Route path="/student/history" element={<ProtectedRoute allowedRoles={['student', 'parent']}><StudentHistory /></ProtectedRoute>} />
      <Route path="/student/report" element={<ProtectedRoute allowedRoles={['student', 'parent']}><StudentReport /></ProtectedRoute>} />
      
      <Route path="/parent" element={<ProtectedRoute allowedRoles={['student', 'parent']}><Student /></ProtectedRoute>} />
      <Route path="/parent/order" element={<ProtectedRoute allowedRoles={['student', 'parent']}><StudentOrder /></ProtectedRoute>} />
      <Route path="/parent/history" element={<ProtectedRoute allowedRoles={['student', 'parent']}><StudentHistory /></ProtectedRoute>} />
      <Route path="/parent/report" element={<ProtectedRoute allowedRoles={['student', 'parent']}><StudentReport /></ProtectedRoute>} />
      
      <Route path="/delivery" element={<ProtectedRoute allowedRoles={['delivery']}><Delivery /></ProtectedRoute>} />
      
      <Route path="*" element={<Navigate to={user ? `/${userRole || 'login'}` : "/login"} replace />} />
    </Routes>
  );
}
