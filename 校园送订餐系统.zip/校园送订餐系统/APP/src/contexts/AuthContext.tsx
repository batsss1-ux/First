import { createContext, useContext, useEffect, useState } from "react";
import { User, Session } from "@supabase/supabase-js";
import { supabase } from "@/db/supabase";

interface AuthContextType {
  user: User | null;
  session: Session | null;
  loading: boolean;
  userRole: string | null;
}

const AuthContext = createContext<AuthContextType>({ user: null, session: null, loading: true, userRole: null });

export const AuthProvider = ({ children }: { children: React.ReactNode }) => {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);
  const [userRole, setUserRole] = useState<string | null>(null);

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      setUser(session?.user ?? null);
      if (session?.user) {
        fetchUserRole(session.user.id);
      } else {
        setLoading(false);
      }
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setSession(session);
      setUser(session?.user ?? null);
      if (session?.user) {
        fetchUserRole(session.user.id);
      } else {
        setUserRole(null);
        setLoading(false);
      }
    });

    return () => subscription.unsubscribe();
  }, []);

  const fetchUserRole = async (userId: string) => {
    const { data, error } = await supabase.from("users").select("role").eq("id", userId).maybeSingle();
    if (!error && data) {
      setUserRole(data.role);
    } else {
      // 如果在用户表中找不到该用户（例如已被删除），则强制登出
      await supabase.auth.signOut();
      setUser(null);
      setSession(null);
      setUserRole(null);
    }
    setLoading(false);
  };

  return <AuthContext.Provider value={{ user, session, loading, userRole }}>{children}</AuthContext.Provider>;
};

export const useAuth = () => useContext(AuthContext);
