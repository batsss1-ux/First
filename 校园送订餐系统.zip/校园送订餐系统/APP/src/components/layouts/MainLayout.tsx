import { ReactNode, useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { LogOut, Menu, User, Utensils, LayoutDashboard, Truck, FileText, Bell, Key, Save } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/db/supabase";
import { toast } from "sonner";

interface MainLayoutProps {
  children: ReactNode;
  role: "admin" | "student" | "parent" | "delivery";
}

export function MainLayout({ children, role }: MainLayoutProps) {
  const { user } = useAuth();
  const navigate = useNavigate();

  const [profileOpen, setProfileOpen] = useState(false);
  const [profileForm, setProfileForm] = useState({ name: "", phone: "", password: "" });
  const [updating, setUpdating] = useState(false);

  useEffect(() => {
    if (user && profileOpen) {
      const fetchUserData = async () => {
        const { data } = await supabase.from('users').select('name, phone').eq('id', user.id).single();
        if (data) {
          setProfileForm({ name: data.name || "", phone: data.phone || "", password: "" });
        }
      };
      fetchUserData();
    }
  }, [user, profileOpen]);

  const handleUpdateProfile = async () => {
    setUpdating(true);
    try {
      if (profileForm.password) {
        const { error: authError } = await supabase.auth.updateUser({ password: profileForm.password });
        if (authError) throw authError;
      }
      
      const { error: dbError } = await supabase.from('users').update({ 
        name: profileForm.name,
        phone: profileForm.phone
      }).eq('id', user?.id);
      
      if (dbError) throw dbError;
      
      toast.success("个人资料已更新！");
      setProfileOpen(false);
    } catch (error: any) {
      toast.error(error.message || "更新失败");
    } finally {
      setUpdating(false);
    }
  };

  const handleLogout = async () => {
    await supabase.auth.signOut();
    toast.success("已退出登录");
    navigate("/login");
  };

  const getNavItems = () => {
    switch (role) {
      case "admin":
        return [
          { name: "控制台", href: "/admin", icon: <LayoutDashboard className="w-5 h-5 mr-2" /> },
          { name: "菜单管理", href: "/admin/menus", icon: <Utensils className="w-5 h-5 mr-2" /> },
          { name: "订单管理", href: "/admin/orders", icon: <FileText className="w-5 h-5 mr-2" /> },
          { name: "配送管理", href: "/admin/delivery", icon: <Truck className="w-5 h-5 mr-2" /> },
          { name: "公告管理", href: "/admin/announcements", icon: <Bell className="w-5 h-5 mr-2" /> },
          { name: "用户管理", href: "/admin/users", icon: <User className="w-5 h-5 mr-2" /> },
        ];
      case "student":
      case "parent":
        return [
          { name: "主页", href: `/${role}`, icon: <LayoutDashboard className="w-5 h-5 mr-2" /> },
          { name: "今日菜单", href: `/${role}/order`, icon: <Utensils className="w-5 h-5 mr-2" /> },
          { name: "我的订单", href: `/${role}/history`, icon: <FileText className="w-5 h-5 mr-2" /> },
          { name: "营养报表", href: `/${role}/report`, icon: <FileText className="w-5 h-5 mr-2" /> },
        ];
      case "delivery":
        return [
          { name: "配送任务", href: "/delivery", icon: <Truck className="w-5 h-5 mr-2" /> },
        ];
      default:
        return [];
    }
  };

  const navItems = getNavItems();

  const NavLinks = ({ onClick }: { onClick?: () => void }) => (
    <div className="flex flex-col gap-2 p-4">
      {navItems.map((item) => (
        <Link
          key={item.href}
          to={item.href}
          onClick={onClick}
          className="flex items-center p-3 text-lg font-bold border-2 border-transparent hover:border-foreground hover:bg-primary/10 transition-colors retro-btn"
        >
          {item.icon}
          {item.name}
        </Link>
      ))}
    </div>
  );

  return (
    <div className="flex min-h-screen w-full bg-background retro-font">
      {/* Desktop Sidebar */}
      <aside className="hidden lg:flex flex-col w-64 shrink-0 border-r-4 border-foreground bg-card retro-shadow">
        <div className="h-16 flex items-center px-6 border-b-4 border-foreground bg-primary text-primary-foreground">
          <Utensils className="w-6 h-6 mr-2" />
          <h1 className="text-xl font-bold">{"校园送订餐系统"}</h1>
        </div>
        <div className="flex-1 overflow-y-auto">
          <NavLinks />
        </div>
        <div className="p-4 border-t-4 border-foreground">
          <div 
            className="flex items-center gap-2 mb-4 px-2 cursor-pointer hover:bg-muted p-2 rounded transition-colors"
            onClick={() => setProfileOpen(true)}
          >
            <User className="w-5 h-5" />
            <div className="flex flex-col min-w-0">
              <span className="font-bold truncate text-sm">{user?.email?.split('@')[0] || user?.email}</span>
              <span className="text-xs text-muted-foreground truncate">点击修改资料</span>
            </div>
          </div>
          <Button 
            variant="destructive" 
            className="w-full retro-shadow retro-btn font-bold text-lg" 
            onClick={handleLogout}
          >
            <LogOut className="w-5 h-5 mr-2" />
            退出登录
          </Button>
        </div>
      </aside>
      {/* Main Content */}
      <div className="flex-1 min-w-0 flex flex-col h-screen overflow-hidden">
        {/* Mobile Header */}
        <header className="lg:hidden h-16 flex items-center justify-between px-4 border-b-4 border-foreground bg-primary text-primary-foreground retro-shadow shrink-0 z-10">
          <div className="flex items-center">
            <Utensils className="w-6 h-6 mr-2" />
            <h1 className="text-xl font-bold">校园送订餐系统</h1>
          </div>
          <Sheet>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="border-2 border-primary-foreground hover:bg-primary-foreground/20 retro-btn">
                <Menu className="w-6 h-6" />
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="w-64 p-0 border-r-4 border-foreground">
              <div className="h-16 flex items-center px-6 border-b-4 border-foreground bg-primary text-primary-foreground">
                <Utensils className="w-6 h-6 mr-2" />
                <h2 className="text-xl font-bold">校园送订餐系统</h2>
              </div>
              <div className="flex-1 overflow-y-auto">
                <NavLinks />
              </div>
              <div className="p-4 border-t-4 border-foreground absolute bottom-0 w-full bg-card">
                <div 
                  className="flex items-center gap-2 mb-4 px-2 cursor-pointer hover:bg-muted p-2 rounded transition-colors"
                  onClick={() => {
                    setProfileOpen(true);
                  }}
                >
                  <User className="w-5 h-5" />
                  <div className="flex flex-col min-w-0">
                    <span className="font-bold truncate text-sm">{user?.email?.split('@')[0] || user?.email}</span>
                    <span className="text-xs text-muted-foreground truncate">点击修改资料</span>
                  </div>
                </div>
                <Button 
                  variant="destructive" 
                  className="w-full retro-shadow retro-btn font-bold text-lg" 
                  onClick={handleLogout}
                >
                  <LogOut className="w-5 h-5 mr-2" />
                  退出登录
                </Button>
              </div>
            </SheetContent>
          </Sheet>
        </header>

        {/* Page Content */}
        <main className="flex-1 min-w-0 overflow-y-auto p-4 md:p-8">
          <div className="max-w-6xl mx-auto">
            {children}
          </div>
        </main>
      </div>

      {/* Profile Dialog */}
      <Dialog open={profileOpen} onOpenChange={setProfileOpen}>
        <DialogContent className="border-4 border-foreground rounded-none retro-shadow bg-card max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader>
            <DialogTitle className="text-2xl font-bold border-b-4 border-foreground pb-2">修改个人资料</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <label className="font-bold text-sm">登录账号</label>
              <Input 
                value={user?.email?.split('@')[0] || ""} 
                disabled 
                className="border-2 border-foreground rounded-none bg-muted font-bold text-muted-foreground"
              />
              <p className="text-xs text-muted-foreground">账号暂不支持修改</p>
            </div>
            <div className="space-y-2">
              <label className="font-bold text-sm">真实姓名</label>
              <Input 
                value={profileForm.name} 
                onChange={(e) => setProfileForm({ ...profileForm, name: e.target.value })}
                className="border-2 border-foreground rounded-none font-bold"
                placeholder="请输入姓名"
              />
            </div>
            <div className="space-y-2">
              <label className="font-bold text-sm">联系电话</label>
              <Input 
                value={profileForm.phone} 
                onChange={(e) => setProfileForm({ ...profileForm, phone: e.target.value })}
                className="border-2 border-foreground rounded-none font-bold"
                placeholder="请输入手机号"
              />
            </div>
            <div className="space-y-2 pt-4 border-t-2 border-dashed border-muted-foreground">
              <label className="font-bold text-sm flex items-center text-accent">
                <Key className="w-4 h-4 mr-1" /> 修改密码（可选）
              </label>
              <Input 
                type="password"
                value={profileForm.password} 
                onChange={(e) => setProfileForm({ ...profileForm, password: e.target.value })}
                className="border-2 border-foreground rounded-none font-bold"
                placeholder="若不修改密码请留空"
              />
            </div>
          </div>
          <DialogFooter className="flex-row justify-end gap-2">
            <Button variant="outline" className="border-2 border-foreground retro-btn font-bold" onClick={() => setProfileOpen(false)}>
              取消
            </Button>
            <Button 
              className="border-2 border-foreground retro-btn retro-shadow font-bold bg-primary text-primary-foreground" 
              onClick={handleUpdateProfile}
              disabled={updating}
            >
              {updating ? "保存中..." : <><Save className="w-4 h-4 mr-2" /> 保存资料</>}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
